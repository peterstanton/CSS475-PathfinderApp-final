CREATE DATABASE  IF NOT EXISTS `PathfinderApp` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `PathfinderApp`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: pathfinder.chpcq7i3yggs.us-west-2.rds.amazonaws.com    Database: PathfinderApp
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PINPOINT`
--

DROP TABLE IF EXISTS `PINPOINT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PINPOINT` (
  `ID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `x_coordinate` float NOT NULL,
  `y_coordinate` float NOT NULL,
  `types` enum('Warning','Landmark','General Information') NOT NULL,
  `description` varchar(280) DEFAULT NULL,
  `image_link` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UID_fk` (`UID`),
  CONSTRAINT `PINPOINT_ibfk_1` FOREIGN KEY (`UID`) REFERENCES `USER` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PINPOINT`
--

LOCK TABLES `PINPOINT` WRITE;
/*!40000 ALTER TABLE `PINPOINT` DISABLE KEYS */;
INSERT INTO `PINPOINT` VALUES (1010,10101,'secret cave?',132.4,99.1,'Landmark','Did you all know about this?','imgur.com/I7fUSDnuj9q'),(2020,19191,'My favorite campsite',321.5,81.2,'Landmark','Highly recommend resting here.','imgur.com/I7fUSDnuj9q'),(3030,18181,'Tree Selfie',159.2,60.41,'Landmark','Just takin selfies w this tree!','imgur.com/I7fUSDnuj9q'),(4040,17171,'Rabbit',423.1,49.1,'Landmark','I think this is a rabbit? It has antlers, and it sounds like a moose, but im pretty sure.','imgur.com/I7fUSDnuj9q'),(6060,15151,'Best view ever',34.4,53.2,'Landmark','I can see my house from here!','imgur.com/I7fUSDnuj9q'),(7070,14141,'Tree',86.4,32.2,'Landmark','Thought this was a yeti.','imgur.com/I7fUSDnuj9q'),(8080,13131,'Cool pinecones!',52.3,90.2,'Landmark','Found best pinecone ever. Definitely 11/10.','imgur.com/I7fUSDnuj9q'),(9090,12121,'John Doe was here',151.1,322,'Landmark','Graffitied my name on this rock','imgur.com/I7fUSDnuj9q'),(19234,98789,'Sgt. Becky Trailhead',3.78,1.29,'General Information','6.6 mile trail down to Joffrey\'s Point.','imgur.com/IPSD87dSj'),(34875,98789,'Blue Lagoon',5.68,11.5,'Landmark','Great fishing spot!','imgur.com/IUSDn7f%DSF'),(87345,77524,'Conor\'s Scenic Trail',8.8,3.41,'Landmark','Well maintained dirt trail through scenic passways. Bikes welcome.','imgur.com/I7fUSDnuj9q'),(87878,98789,'Fallen Tree',45,62,'Warning','A log has fallen over the path here. It will be cleared shortly','imgur.com/I7fUSDnuj9q'),(98989,23232,'Beautiful sunrise',321.2,23.61,'Landmark','Title says it all. Good to get away from the big city.','imgur.com/I7fUSDnuj9q');
/*!40000 ALTER TABLE `PINPOINT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-10 19:22:14
