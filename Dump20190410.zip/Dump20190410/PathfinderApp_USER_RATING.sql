CREATE DATABASE  IF NOT EXISTS `PathfinderApp` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `PathfinderApp`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: pathfinder.chpcq7i3yggs.us-west-2.rds.amazonaws.com    Database: PathfinderApp
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `USER_RATING`
--

DROP TABLE IF EXISTS `USER_RATING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_RATING` (
  `PID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `rating` tinyint(1) NOT NULL,
  `description` varchar(280) DEFAULT NULL,
  PRIMARY KEY (`PID`,`UID`),
  KEY `UID_fk` (`UID`),
  CONSTRAINT `USER_RATING_ibfk_1` FOREIGN KEY (`PID`) REFERENCES `PINPOINT` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `USER_RATING_ibfk_2` FOREIGN KEY (`UID`) REFERENCES `USER` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_RATING`
--

LOCK TABLES `USER_RATING` WRITE;
/*!40000 ALTER TABLE `USER_RATING` DISABLE KEYS */;
INSERT INTO `USER_RATING` VALUES (1010,13131,1,'I love caves!!! And secrets!!!'),(1010,17171,1,'Maybe it has rabbits inside?'),(2020,13131,1,'I love campsites!'),(3030,12121,0,'Will you millentials ever stop it with these??!'),(3030,13131,1,'I love selfies!'),(4040,13131,1,'I love rabbits'),(4040,14141,1,'Actually, thats a deer. Looks nice tho'),(6060,13131,1,'Every view is the best view ever!'),(6060,14141,1,'Perhaps hyberbolic to say the best, but def good'),(6060,15151,1,'I like parks'),(6060,16161,1,'Enjoy it while it lasts. Corporations are gonna steal this land. WAKE UP SHEEPLE!'),(7070,13131,1,'Accurate description. Defintitely a tree.'),(7070,14141,1,'TREES! THERE EVERYWHERE'),(8080,10101,1,'Decent.'),(8080,12121,1,'Totally agree. Maybe even 13/10.'),(8080,14141,1,'I would say 8/10, but its still prtty good.'),(8080,15151,1,'Pinecones FTW!'),(8080,16161,1,'How the fudge does a pinecone look so good???.'),(8080,17171,1,'Pretty sure thats a rabbit.'),(8080,18181,1,'I hate pinecones, but I like your gumption.'),(8080,19191,1,'help i think im lost. good pinecone tho.'),(9090,13131,0,'Not cool.'),(19234,98789,0,'The trail there was overgrown with blackberry bushes. Not the best hiking experience.'),(34875,12345,1,'Nice hillside location - perfect for the sunset!'),(34875,98789,1,'Great place for fishing. Wear long boots and water resistant clothing.'),(87345,77524,1,'Great trail for a bike ride!'),(87345,93472,1,'Nice trail. 80 minutes to reach this point from the trailhead - so be ready for an extensive hike.');
/*!40000 ALTER TABLE `USER_RATING` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-10 19:22:04
