CREATE DATABASE  IF NOT EXISTS `PathfinderApp` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `PathfinderApp`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: pathfinder.chpcq7i3yggs.us-west-2.rds.amazonaws.com    Database: PathfinderApp
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `LANDSCAPE`
--

DROP TABLE IF EXISTS `LANDSCAPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LANDSCAPE` (
  `ID` int(11) NOT NULL,
  `MID` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(280) DEFAULT NULL,
  `x_coordinate_center` float NOT NULL,
  `y_coordinate_center` float NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `MID_fk` (`MID`),
  CONSTRAINT `LANDSCAPE_ibfk_1` FOREIGN KEY (`MID`) REFERENCES `MAP` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LANDSCAPE`
--

LOCK TABLES `LANDSCAPE` WRITE;
/*!40000 ALTER TABLE `LANDSCAPE` DISABLE KEYS */;
INSERT INTO `LANDSCAPE` VALUES (12345,54321,'Northern Plains','These plains are only remarkable in that they reside in the northern part of our park.',43.5,90.1),(23456,54321,'Southern Plains','Similar to the Northern Plains, but further south.',45.2,10.25),(34567,10293,'Old Man\'s Pond','This pond, now inhabited by ducks, once belonged to a man, now old.',50.2,50.1),(45678,67890,'Old Hill','A completely unremarkable hill.',10.5,90.1),(56789,9876,'Young Hill','A fantastic hill, filled with youth and exhuberance',45.2,10.25),(67890,98765,'Triangular Field','This field is historically revered for its geometric shape.',50.5,50.5),(78901,87654,'The Western Wood','',400,250);
/*!40000 ALTER TABLE `LANDSCAPE` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Chris`@`%`*/ /*!50003 TRIGGER `landscape_before_insert` BEFORE INSERT ON `LANDSCAPE`
FOR EACH ROW
BEGIN
    CALL check_landscape(new.x_coordinate_center,new.y_coordinate_center);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Chris`@`%`*/ /*!50003 TRIGGER `landscape_before_update` BEFORE UPDATE ON `LANDSCAPE`
FOR EACH ROW
BEGIN
    CALL check_landscape(new.x_coordinate_center,new.y_coordinate_center);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-10 19:22:12
